import pygame

pygame.init()

# 设置窗口尺寸
screen_width = 640
screen_height = 480

# 创建窗口
screen = pygame.display.set_mode((screen_width, screen_height))

# 设置窗口标题
pygame.display.set_caption("Pygame Example")

# 主循环
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 设置背景颜色
    screen.fill((255, 255, 255))

    # 更新显示
    pygame.display.flip()

pygame.quit()
