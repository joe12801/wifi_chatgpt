import requests

def chatbot_interaction(session_id, username, message):
    url = "http://jd64.994938.xyz:8234/v1/chat"
    headers = {'Content-Type': 'application/json'}
    data = {
        "session_id": session_id,
        "username": username,
        "message": message
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response_data = response.json()
        if response_data["result"] == "DONE":
            message = response_data["message"][0]
            return message
    except requests.exceptions.RequestException as e:
        print("发生错误：", e)
    
    return None

def main():
    # 设置会话参数
    session_id = "friend-123456"
    username = "testuser"

    # 发送消息
    message = input("请输入消息：")
    response = chatbot_interaction(session_id, username, message)
    

    # 处理响应
    if response is not None:
        print("回复：", response)

if __name__ == "__main__":
    main()
