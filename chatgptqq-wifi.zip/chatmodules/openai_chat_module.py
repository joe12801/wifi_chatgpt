import requests



class OpenaiChatModule:





    def chatbot_interaction(session_id, username, message):
        url = "http://jd64.994938.xyz:8234/v1/chat"
        headers = {'Content-Type': 'application/json'}
        data = {
            "session_id": session_id,
            "username": username,
            "message": message
        }

        try:
            response = requests.post(url, headers=headers, json=data)
            response_data = response.json()
            if response_data["result"] == "DONE":
                message = response_data["message"][0]
                return message
        except requests.exceptions.RequestException as e:
            print("发生错误：", e)
        
        return None


